﻿using Tic_Tac_Toe_Game;

internal class Program
{

    private static void Main(string[] args)
    {
        Game game = new Game();
        game.Start();   

        
    }

        
}